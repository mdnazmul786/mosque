<?php

class Prayers_Model extends CI_Model {

    public function save_prayers_data(array $data) {
        $whereclaus = array(
            'MosjidNo' => subdomainid,
            'PrayerName' => $data['PrayerName'],
        );

        $this->db->select('*');
        $this->db->from('cl_prayer_times');

        $this->db->where($whereclaus);

        $query = $this->db->get();
        $result = $query->row();

        if (count($result) > 0) {

            $this->db->where('PrayerId',$result->PrayerId);
            $this->db->update('cl_prayer_times', $data);
        } else {

            $this->db->insert('cl_prayer_times', $data);
        }
    }

    public function getall_prayerstime() {

        $this->db->select('*');
        $this->db->from('cl_prayer_times');

        $this->db->where('MosjidNo',subdomainid);
        $this->db->where('PrayerStatus',1);
        $query = $this->db->get();
        $result = $query->result();

        return $result;
    }

    public function delete_prayerid($pid) {
        $whereclaus = array(
            'MosjidNo' => subdomainid,
            'PrayerId' => $pid,
        );
        $data = array(
            'PrayerStatus' => 0
        );
        $this->db->where($whereclaus);
        $this->db->update('cl_prayer_times', $data);
    }

}
