<div class="inner-header">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1>About Us</h1>
            </div>
            <div class="col-md-5">
                <ul class="cp-breadcrumb">
                    <li><a href="index-2.html">Home</a></li>
                    <li> <a href="#">About Us</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>