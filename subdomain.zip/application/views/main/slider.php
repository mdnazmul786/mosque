<div class="cp-main-slider">
    <div class="cp-masjid-img"><img src="<?php echo base_url(); ?>include/front/images/masjid.png" alt=""></div>
    <div id="main-slider" class="owl-carousel owl-theme">
        <div class="item">
            <div class="slider-caption"> <img src="<?php echo base_url(); ?>include/front/images/banner2-text1.png" alt="">
                <h1>There is no one worthy of worship except Allah<br>
                    and Muhammad (PBUH) is His Messenger</h1>
                <a href="#">Learn More</a> </div>
            <img src="<?php echo base_url(); ?>include/front/images/mslider.jpg" alt=""></div>
        <div class="item">
            <div class="slider-caption">
                <h1>Save yourself from Hell-fire even by <br>
                    giving half a date-fruit in charity.</h1>
                <a href="#">Learn More</a> </div>
            <img src="<?php echo base_url(); ?>include/front/images/mslider2.jpg" alt=""></div>
        <div class="item">
            <div class="slider-caption">
                <h1>It is Islam that has made <br>
                    "Muslims Great"</h1>
                <a href="#">Learn More</a> </div>
            <img src="<?php echo base_url(); ?>include/front/images/mslider3.jpg" alt=""></div>
    </div>
</div>